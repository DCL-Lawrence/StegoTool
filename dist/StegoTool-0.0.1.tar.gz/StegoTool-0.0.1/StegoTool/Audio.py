import math
import librosa
import numpy as np
import soundfile as sf
from dataclasses import dataclass

@dataclass
class Audio():
    def __init__(self, filename):
        self.name:str = filename

        self.sr:float
        self.sound, self.sr = librosa.load(filename, dtype = np.float32)

        self.nbits:list = []

    # Sample seq: "102"
    # Variable seq as period.
    def select(self, seq) -> None:
        for i in range(len(seq)):
            if(int(seq[i]) <= 2):
                self.nbits.append(int(seq[i]))
            else:
                raise ValueError(f"Invalid bit used {seq[i]} is longer than 2.")

    def reselect(self, seq) -> None:
        self.select(seq)

    # The maxmim value for  bit is two.
    # Variable number is the secret data.
    def hiding(self, amplipude, bit ,number) -> float:
        amplipude -= (amplipude % math.pow(2, bit))
        return amplipude + float(number)

    def check(self, data):
        P = self.nbits

        L = len(P)
        D = 7 * len(data)
        N:int = L * (D // sum(P))
        left:int = D % sum(P)
        count:int = 0

        for i in range(L):
            if(left > 0):
                count += 1
                left -= P[i]
            else:
                break

        if(N + count > len(self.sound)):
            return False, None, None
        else:
            # Return the number of bits need be filled and the number of pixel used.
            return True, left, N + count


    def create(self, data) -> None:
        check, left, count = self.check(data)

        if(check == False):
            raise RuntimeError("The data is too long to hide into the audio you gave")

        # Convert data into bit stream
        binstr:str = ""
        for c in data:
            bits = bin(ord(c))[2:].zfill(7)
            binstr += bits
        
        # Padding with 0
        for i in range(abs(left)):
            binstr += '0'

        for i in range(count):
            string = binstr[0 : self.nbits[i % len(self.nbits)]]
            if(self.nbits[i % len(self.nbits)] != 0):
                self.sound[i] = self.hiding(self.sound[i], self.nbits[i % len(self.nbits)], int(string, 2))
            binstr = binstr[self.nbits[i % len(self.nbits)] :]

        self.save_audio("New" + self.name)

    def save_audio(self, filename) -> None:
        format = filename[filename.find('.') + 1 :]
        sf.write(filename, self.sound, self.sr, format = format,subtype = "PCM_24")

    def extracting(self, amplipude, bit) -> int:
        return int(amplipude % math.pow(2, bit))
    
    def get(self) -> None:
        binstr:str = ""

        for i in range(len(self.sound)):
            if(self.nbits[i % len(self.nbits)] != 0):
                value = self.extracting(self.sound[i], self.nbits[i % len(self.nbits)])
                binstr += bin(value)[2:].zfill(self.nbits[i % len(self.nbits)])

        while(len(binstr) % 7 != 0):
            binstr += '0'

        string:str = ""
        for i in range(0, len(binstr), 7):
            value = binstr[i:i+7]
            string += chr(int(value, 2))
        
        self.save_data(string)

    def save_data(self, string) -> None:
        open("secret.txt", 'w').write(string)
